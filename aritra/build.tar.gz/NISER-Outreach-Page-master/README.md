# NISER Outreach Page

This is a page which I have made  as an entry to the Outreach Page Competition setup by NISER Coding Club. Before this, I didn't know a bit about making web pages. So I learn't how to build one and kept on building it on the go.



## Acknowledgements

 - I took immense help from [Bootstrap](https://getbootstrap.com/).
 - I took an the idea of the hamburger menu from [this](https://github.com/robotechniser/robotechniser.github.io) github repository, which i hosted [here](https://robotechniser.github.io).
 - I took the code for the calendar from [here](https://github.com/lashaNoz/Calendar) which has been described in [this](https://www.youtube.com/watch?v=o1yMqPyYeAo) youtube video.
 - While making the Time Lapse Video, I used Microsoft Powerpoint and added a song from [this](https://www.youtube.com/watch?v=b8JbxVDzB-k&t=2106s) YouTube video.

 ## Attractive Features
 - The page has 3 themes one of them have been activated, to unlock the other two, unlock them from the css file (they are commented in the **calendar** section, just uncomment them).
 - Interactive Hamburger Menu
    
## The site is currently hosted at 
https://peithonking.github.io/NISER-Outreach-Page/

### Thanks