// function show() {
//   document.querySelector('div').forEach(div => {
//     div.style.display = 'none';
//   });
//   document.querySelector('div').style.display = 'block';
// }
// document.addEventListener('DOMContentLoaded',function(){
//   show();
// });

// document.querySelector("#logo").style.backgroundColor = "red";
