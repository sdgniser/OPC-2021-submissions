# OPC
Niser Outreach Web page Project
BOOTSTRAP:
Used JS deliver(could not figure out how to find unpkg links or whether to locally install) to export .css and .js packages.
